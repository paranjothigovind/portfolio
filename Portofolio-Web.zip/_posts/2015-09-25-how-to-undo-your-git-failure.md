---
title: How to undo your git failure?
tags: [External Post, Git]
style: fill
color: warning
description: Using `git reflog` and `git reset` to save your code.
external_url: https://blog.usejournal.com/how-to-undo-your-git-failure-b76e31ecac74
---